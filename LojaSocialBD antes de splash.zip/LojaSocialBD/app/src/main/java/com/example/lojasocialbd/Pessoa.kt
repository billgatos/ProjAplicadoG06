package com.example.lojasocialbd

class Pessoa {
}